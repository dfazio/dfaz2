This repository include the html, css and javascript files to have a starting point for the assignment 2. 
